package org.eset.eset;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EsetApplication {

	public static void main(String[] args) {
		SpringApplication.run(EsetApplication.class, args);
	}
}
